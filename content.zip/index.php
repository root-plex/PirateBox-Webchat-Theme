<?php
// (A) LOGIN CHECKS
require "process.php";

// (B) LOGIN PAGE HTML ?>
<!DOCTYPE html>
<html>
  <head>
    <title>
      Login Page
    </title>
    <link href="/content/css/login.css" rel="stylesheet">
    <meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
  </head>
  <body>
    <?php if (isset($failed)) { ?>
    <div id="bad-login">Invalid email or password.</div>
    <?php } ?>
      <form id="login-form" method="post" target="_self">
        <center><h1>PLEASE SIGN IN</h1></center>
        <label for="user">User</label>
        <input type="text" name="user" required/>
        <label for="password">Password</label>
        <input type="password" name="password" required/>
        <input type="submit" value="Sign In"/>
      </form>
  <script id="allow-copy_script">
    (function agent() {
        let isUnlockingCached = false
        const isUnlocking = () => isUnlockingCached
        document.addEventListener('allow_copy', event => {
            const {
                unlock
            } = event.detail
            isUnlockingCached = unlock
        })
        document.addEventListener('contextmenu', event => event.preventDefault())
        const copyEvents = [
            'copy',
            'cut',
            'contextmenu',
            'selectstart',
            'mousedown',
            'mouseup',
            'mousemove',
            'keydown',
            'keypress',
            'keyup',
        ]
        const rejectOtherHandlers = e => {
            if (isUnlocking()) {
                e.stopPropagation()
                if (e.stopImmediatePropagation) e.stopImmediatePropagation()
            }
        }
        copyEvents.forEach(evt => {
            document.documentElement.addEventListener(evt, rejectOtherHandlers, {
                capture: true,
            })
        })
    })()
  </script>
  </body>
</html>