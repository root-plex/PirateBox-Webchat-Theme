<!DOCTYPE html>
<?php
// (A) START SESSION
session_start();

// (B) LOGOUT REQUEST
if (isset($_POST['logout'])) { unset($_SESSION['user']); }

// (C) REDIRECT TO LOGIN PAGE IF NOT LOGGED IN
if (!isset($_SESSION['user'])) {
  header("Location: index.php");
  exit();
}
?>
<html>
    <head>
        <link rel="stylesheet" href="/content/css/upload.css" />
        <title>Upload</title>
        <script src="/content/js/jquery.min.js"></script>
        <script src="/content/js/scripts.js"></script>
        <link rel="stylesheet" href="/css/jquery-ui.min.css" />
        <script src="/content/js/jquery-ui.min.js"></script>
        <meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" />

        <link rel="prefetch" type="application/l10n" href="locales/locales.ini" />
        <script type="text/javascript" src="/content/js/l10n.js"></script>
    </head>
    <center><br /><br /><br /><br /><br /><br />
    <body id="main-index">
        <div id="sidebar">
            <div id="upload" class="card">
                <iframe src="http://piratebox.lan:8080" data-l10n-id="sidebarIframeNotSupported" style="color: transparent;" scrolling="no" width="100%" height="80">Your browser does not support iframes.. If you want to upload something, follow this</iframe>
                <br /><br /><h3><a href="/Shared" data-l10n-id="sidebarBrowseFiles">Browse Files</a></h3>
                <div id="station"></div>
            </div>
            
        </div>
    </body>
</center>
</html>
