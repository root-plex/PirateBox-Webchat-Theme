<script id="allow-copy_script">
    (function agent() {
        let isUnlockingCached = false
        const isUnlocking = () => isUnlockingCached
        document.addEventListener('allow_copy', event => {
            const {
                unlock
            } = event.detail
            isUnlockingCached = unlock
        })
        document.addEventListener('contextmenu', event => event.preventDefault())
        const copyEvents = [
            'copy',
            'cut',
            'contextmenu',
            'selectstart',
            'mousedown',
            'mouseup',
            'mousemove',
            'keydown',
            'keypress',
            'keyup',
        ]
        const rejectOtherHandlers = e => {
            if (isUnlocking()) {
                e.stopPropagation()
                if (e.stopImmediatePropagation) e.stopImmediatePropagation()
            }
        }
        copyEvents.forEach(evt => {
            document.documentElement.addEventListener(evt, rejectOtherHandlers, {
                capture: true,
            })
        })
    })()
